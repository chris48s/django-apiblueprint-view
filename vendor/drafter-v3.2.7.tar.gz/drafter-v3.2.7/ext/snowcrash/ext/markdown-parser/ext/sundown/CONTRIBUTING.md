Contributing to Sundown
=======================

Do not.

Unfortunately, Sundown is currently frozen as we're working with the Reddit, StackOverflow and Meteor developers to design a formal Markdown standard and parser that will supersede Sundown in all these websites (and in GitHub, of course). Our goal is to deprecate Sundown altogether before the end of the year.

The new parser will be smaller, faster, safer and most importantly, more consistent.

Please stay tuned.