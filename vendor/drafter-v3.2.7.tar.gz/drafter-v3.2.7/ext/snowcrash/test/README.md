# Snow Crash Test Suite

https://github.com/philsquared/Catch/wiki

---

TODO: