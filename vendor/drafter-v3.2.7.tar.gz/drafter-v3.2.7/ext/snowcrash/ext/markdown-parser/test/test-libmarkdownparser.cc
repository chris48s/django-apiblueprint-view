//
//  main.cpp
//  test-libmarkdownparser
//
//  Created by Zdenek Nemec on 4/18/14.
//  Copyright (c) 2014 Apiary Inc. All rights reserved.
//

#define CATCH_CONFIG_MAIN /// < Let catch generate the main()
#include "catch.hpp"
